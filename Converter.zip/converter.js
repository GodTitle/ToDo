const RATES = {
    USD:0.013,
    EUR:0.012
};

function convert( RUB, currency ){
    if (!RATES[currency]){
        return null;
    }
    return RUB * RATES [currency];
}